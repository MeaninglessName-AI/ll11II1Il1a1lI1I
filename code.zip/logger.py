import logging

logging.basicConfig(level=logging.DEBUG)
LOGGER = logging.getLogger(__name__)